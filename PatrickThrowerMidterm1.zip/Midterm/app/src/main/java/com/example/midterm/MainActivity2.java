package com.example.midterm;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Objects;

public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        TextView input, conversion;
        Button modify = null;

        modify.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity2.this);
                builder.setIcon(com.google.android.material.R.drawable.m3_password_eye);
                builder.setTitle("Modify");
                builder.setMessage("Do you want to modify the amount?");
                builder.setCancelable(true);
                builder.setPositiveButton("Modify", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(MainActivity2.this, "Modify", Toast.LENGTH_SHORT).show();
                        Intent i = new Intent(getApplicationContext(), MainActivity.class);
                    }
                });

                builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(MainActivity2.this, "Cancel", Toast.LENGTH_SHORT).show();
                    }
                });

                builder.setNeutralButton("Exit", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
            }
        });

        input = findViewById(R.id.origInput);
        conversion = findViewById(R.id.convertedAmount);

        Intent i2 = getIntent();
        String currency = i2.getStringExtra("Currency");
        double amount = Double.parseDouble(i2.getStringExtra("Amount"));

        if(Objects.equals(currency, "MXN") )
            amount *= 20;
        if(Objects.equals(currency, "CAD") )
            amount *= 1.25;
        if(Objects.equals(currency, "EURO") )
            amount *= 0.85;
        if(Objects.equals(currency, "INR") )
            amount *= 75;

        String output1 = String.format("The original input is: %s", currency);
        String output2 = String.format("The converted output is: %.2f", amount);

        input.setText(output1);
        conversion.setText(output2);

    }
}