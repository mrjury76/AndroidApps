package com.example.midterm;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        EditText input = findViewById(R.id.inputEditText);
        ListView list = findViewById(R.id.listView);

        String[] currency = {"MEX", "CAD", "EURO", "INR"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, R.layout.activity_main, R.id.inputEditText, currency);

        list.setAdapter(adapter);

        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if(input == null){
                    Toast.makeText(MainActivity.this, "please enter an amount", Toast.LENGTH_SHORT).show();
                }
                String item = currency[position];
                Intent i = new Intent(getApplicationContext(), MainActivity2.class);
                i.putExtra("Currency", item);
                i.putExtra("Amount", input.getText().toString());
                startActivity(i);
            }
        });


    }
}